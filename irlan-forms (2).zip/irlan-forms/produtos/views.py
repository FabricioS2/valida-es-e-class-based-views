from django.shortcuts import render, redirect
from .forms import CategoriaForm, FornecedorForm, ProdutoForm
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView
from .models import Categoria, Fornecedor, Produto


# Create your views here.



def home(request):
    return render(request, 'home.html')


#def cadastrar_categoria(request):
#    if request.method == 'POST':
#        form = CategoriaForm(request.POST)
#        if form.is_valid():
#            form.save()
#            #return redirect('sucesso')  # Redireciona após sucesso
#    else:
#        form = CategoriaForm()
#    return render(request, 'cadastrar_categoria.html', {'form': form})





#def cadastrar_fornecedor(request):
#    if request.method == 'POST':
#        form = FornecedorForm(request.POST)
#        if form.is_valid():
#            form.save()
            #return redirect('sucesso')
#    else:
#        form = FornecedorForm()
#    return render(request, 'cadastrar_fornecedor.html', {'form': form})

#def cadastrar_produto(request):
#    if request.method == 'POST':
#        form = ProdutoForm(request.POST)
#        if form.is_valid():
#            form.save()
           # return redirect('sucesso')
#    else:
#        form = ProdutoForm()
#    return render(request, 'cadastrar_produto.html', {'form': form})



class cadastrar_categoria(CreateView):
    model = Categoria
    form_class = CategoriaForm
    template_name = 'cadastrar_categoria.html'
    success_url = reverse_lazy('cadastrar_categoria')  


class cadastrar_fornecedor(CreateView):
    model = Fornecedor
    form_class = FornecedorForm
    template_name = 'cadastrar_fornecedor.html'
    success_url = reverse_lazy('cadastrar_fornecedor')  


class cadastrar_produto(CreateView):
    model = Produto
    form_class = ProdutoForm
    template_name = 'cadastrar_produto.html'
    success_url = reverse_lazy('cadastrar_produto')  